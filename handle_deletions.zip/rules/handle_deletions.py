from sets import Set
from com.xebialabs.deployit.plugin.api.deployment.specification import Operation
from os.path import exists, join, isfile
from os import listdir

class deployed_helper:
    def __init__(self, deployed, steps):
        self.deployed = deployed
        self.__deployed = deployed._delegate
        self.artifact_folder = deployed.getFile().path
        self.steps = steps

    def list_files(self):
        return [ff for ff in listdir(self.artifact_folder) if isfile(self.path_of(ff))]

    def list_rollback_files(self):
        return []

    def path_of(self, script_name):
        return join(self.artifact_folder, script_name)

    def move_files_step(self, files, options=None):
        step = self.steps.os_script(
            description="Remove %s on %s" % (str(files), self.deployed.container.name),
            order=40,
            script='rules/move_deleted_files',
            target_host=self.deployed.container.host,
            freemarker_context={'files': files, 'deployed': self.__deployed,
                                'container': self.deployed.container}
        )

        return step

    def restore_files_step(self, script, options=None):
        step = self.__script_step(script, self.deployed.destroyOrder, "Restore")
        return step

    def __script_step(self, script, order, verb):
        step = self.steps.os_script(
            description="%s %s on %s" % (verb, script, self.deployed.container.name),
            order=order,
            script=self.deployed.getExecutorScript(),
            target_host=self.deployed.container.host,
            freemarker_context={'sqlScriptToExecute': script, 'deployed': self.__deployed,
                                'container': self.deployed.container}
        )

        return step


def difference(left_set, right_set):
    s = Set()
    for f in left_set:
        if f not in right_set:
            s.add(f)
        else:
            pass
    return s

helper = deployed_helper(deployed, steps)
previous_helper = deployed_helper(previousDeployed, steps)

current_files = helper.list_files()
previous_files = previous_helper.list_files()
current_set = Set(current_files)
previous_set = Set(previous_files)

removed_files = list(difference(previous_set, current_set))

if removed_files:
	remove_step = previous_helper.move_files_step(removed_files)
	context.addStep(remove_step)